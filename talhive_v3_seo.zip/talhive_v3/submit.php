<?php
/**
 * Talhive lead-capture handler.
 *
 * Accepts JSON POST from any form on the site and emails the lead to:
 *   som@talhive.com, pratik@talhive.com, marketing@talhive.com, shubham@talhive.com
 * All form mail is SENT FROM marketing@talhive.com.
 * Also sends a branded autoresponder to the lead.
 *
 * Also logs every submission to leads.log (one JSON line per lead) as a
 * deliverability fallback — so even if mail() fails silently, every lead is
 * recoverable from the server log.
 *
 * Anti-spam:
 *   - Honeypot field "website" (must be empty)
 *   - Time-trap (rejects submissions in < 2 seconds via form_started_at)
 *   - Server-side validation (email format, non-empty name)
 *   - Rate-limit by IP (max 5 submissions per IP per 10 minutes)
 *
 * Designed to be robust against silent failure. Mail delivery on shared
 * hosting is unreliable — the leads.log file is the source of truth.
 */

// ────────────────────────────────────────────────────────────────────
// Configuration
// ────────────────────────────────────────────────────────────────────
$RECIPIENTS = [
    'som@talhive.com',
    'pratik@talhive.com',
    'marketing@talhive.com',
    'shubham@talhive.com',
];
// NOTE: marketing@talhive.com must exist as a real mailbox on Hostinger and be
// SPF/DKIM-aligned. Form mail is sent from this address only. search@talhive.com
// remains the public contact address on the website and is not used here.
$FROM_ADDRESS = 'marketing@talhive.com';  // Must be on the talhive.com domain for SPF/DKIM alignment
$FROM_NAME    = 'Talhive';
$LOG_FILE     = __DIR__ . '/leads.log';
$RATELIMIT_FILE = __DIR__ . '/.ratelimit.json';
$RATELIMIT_MAX = 5;                    // Max submissions per IP
$RATELIMIT_WINDOW = 600;               // 10 minutes
$MIN_FORM_TIME = 2;                    // Reject if submitted in less than 2 seconds

// ────────────────────────────────────────────────────────────────────
// Response helpers
// ────────────────────────────────────────────────────────────────────
header('Content-Type: application/json');

function respond_ok() {
    http_response_code(200);
    echo json_encode(['ok' => true]);
    exit;
}

function respond_err($msg, $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

// ────────────────────────────────────────────────────────────────────
// Only accept POST
// ────────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond_err('Method not allowed', 405);
}

// ────────────────────────────────────────────────────────────────────
// Parse JSON body (Formspree-style submissions used this)
// Also fall back to standard form-encoded POST
// ────────────────────────────────────────────────────────────────────
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    $data = $_POST;
}
if (!is_array($data)) {
    respond_err('Invalid request body');
}

// ────────────────────────────────────────────────────────────────────
// Anti-spam #1: honeypot
// If filled, it's a bot. Pretend success to not give bots feedback.
// ────────────────────────────────────────────────────────────────────
if (!empty($data['website']) || !empty($data['url']) || !empty($data['phone_number'])) {
    respond_ok();
}

// ────────────────────────────────────────────────────────────────────
// Anti-spam #2: time trap
// If form_started_at is present and submission took < 2 seconds, it's a bot.
// We don't reject hard — just pretend success.
// ────────────────────────────────────────────────────────────────────
if (!empty($data['form_started_at'])) {
    $elapsed = time() - intval($data['form_started_at']);
    if ($elapsed >= 0 && $elapsed < $MIN_FORM_TIME) {
        respond_ok();
    }
}

// ────────────────────────────────────────────────────────────────────
// Anti-spam #3: rate-limit per IP
// ────────────────────────────────────────────────────────────────────
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$ratelimit = [];
if (file_exists($RATELIMIT_FILE)) {
    $ratelimit = json_decode(@file_get_contents($RATELIMIT_FILE), true) ?: [];
}
// Purge old entries
$now = time();
foreach ($ratelimit as $rip => $times) {
    $ratelimit[$rip] = array_values(array_filter($times, function($t) use ($now, $RATELIMIT_WINDOW) {
        return ($now - $t) < $RATELIMIT_WINDOW;
    }));
    if (empty($ratelimit[$rip])) unset($ratelimit[$rip]);
}
// Check this IP
if (isset($ratelimit[$ip]) && count($ratelimit[$ip]) >= $RATELIMIT_MAX) {
    respond_err('Too many submissions. Please try again later.', 429);
}
// Record this submission
$ratelimit[$ip][] = $now;
@file_put_contents($RATELIMIT_FILE, json_encode($ratelimit), LOCK_EX);

// ────────────────────────────────────────────────────────────────────
// Field sanitization & validation
// Pull the fields we care about, sanitize, validate.
// ────────────────────────────────────────────────────────────────────
function clean($s, $max = 500) {
    $s = is_string($s) ? trim($s) : '';
    $s = substr($s, 0, $max);
    return $s;
}
function clean_long($s, $max = 5000) {
    return clean($s, $max);
}

$name    = clean($data['name'] ?? '');
$email   = clean($data['email'] ?? '');
$company = clean($data['company'] ?? '');
$message = clean_long($data['message'] ?? '');
$service = clean($data['service_area'] ?? '');
$page    = clean($data['page'] ?? '');
$phone   = clean($data['phone'] ?? '');
$role    = clean($data['role'] ?? '');
$asset   = clean($data['asset'] ?? '');
$search_model = clean($data['search_model'] ?? '', 120);
$lead_intent = clean($data['lead_intent'] ?? '', 80);
$lead_type = clean($data['lead_type'] ?? '', 20);
$lead_tracking_id = clean($data['lead_id'] ?? '', 30);
$ft_source = clean($data['first_touch_source'] ?? '', 80);
$ft_medium = clean($data['first_touch_medium'] ?? '', 80);
$ft_campaign = clean($data['first_touch_campaign'] ?? '', 120);
$ft_referrer = clean($data['referrer'] ?? '', 250);
$ft_landing = clean($data['landing_page'] ?? '', 250);

// Country routing (client resolves: phone dropdown -> geo-IP -> locale).
// Server derives the calendar owner authoritatively: India = Pratik, else Som.
$country = strtolower(clean($data['country'] ?? '', 8));
$calendar_owner = ($country === 'in') ? 'pratik' : 'som';
// If the client somehow sent an owner, only trust it when consistent.
$client_owner = strtolower(clean($data['calendar_owner'] ?? '', 8));
if ($country === '' && ($client_owner === 'pratik' || $client_owner === 'som')) {
    $calendar_owner = $client_owner;
}
// Stable lead id used across notification email, autoresponder, leads.log,
// deck-download tracking and GA4 events.
$lead_id = 'TH-' . strtoupper(base_convert((string)$now, 10, 36)) . '-' . strtoupper(bin2hex(random_bytes(2)));

// Validate email format (basic but reliable)
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond_err('Invalid email address');
}
// Block personal/free email providers — Talhive only works with firms (not personal capacity)
$PERSONAL_DOMAINS = [
    'gmail.com', 'googlemail.com',
    'yahoo.com', 'yahoo.co.in', 'yahoo.co.uk', 'ymail.com', 'rocketmail.com',
    'hotmail.com', 'outlook.com', 'live.com', 'msn.com',
    'aol.com', 'icloud.com', 'me.com', 'mac.com',
    'protonmail.com', 'proton.me',
    'gmx.com', 'mail.com',
];
$emailDomain = strtolower(substr(strrchr($email, '@'), 1));
if (in_array($emailDomain, $PERSONAL_DOMAINS, true)) {
    respond_err('Please add your official ID.');
}
// Validate non-empty name (or company — at least one identifying field)
if ($name === '' && $company === '') {
    respond_err('Name or company is required');
}

// ────────────────────────────────────────────────────────────────────
// Format the email body
// ────────────────────────────────────────────────────────────────────
$timestamp_utc = gmdate('Y-m-d H:i:s');
$timestamp_ist = gmdate('Y-m-d H:i:s', $now + 19800); // IST = UTC + 5:30

$body_lines = [];
$body_lines[] = "New lead from talhive.com";
$body_lines[] = str_repeat('—', 36);
$body_lines[] = "";
if ($name)    $body_lines[] = "Name:       $name";
if ($email)   $body_lines[] = "Email:      $email";
if ($company) $body_lines[] = "Company:    $company";
if ($phone)   $body_lines[] = "Phone:      $phone";
if ($role)    $body_lines[] = "Role:       $role";
if ($service) $body_lines[] = "Service:    $service";
if ($search_model) $body_lines[] = "Search model:  $search_model";
if ($lead_intent) $body_lines[] = "Intent:     $lead_intent";
if ($lead_type) $body_lines[] = "Lead Type:  $lead_type";
$lead_status = ($search_model && stripos($search_model, 'No, we are only considering contingent') === 0) ? 'Unqualified but Captured' : '';
if ($lead_status) $body_lines[] = "Lead Status: $lead_status";
if ($lead_tracking_id) $body_lines[] = "Lead ID:    $lead_tracking_id";
if ($ft_source && $ft_source !== '(direct)') $body_lines[] = "Source:     $ft_source / $ft_medium";
if ($ft_campaign) $body_lines[] = "Campaign:   $ft_campaign";
if ($asset)   $body_lines[] = "Asset:      $asset";
if ($message) {
    $body_lines[] = "";
    $body_lines[] = "Message:";
    $body_lines[] = $message;
}
$body_lines[] = "";
$body_lines[] = str_repeat('—', 36);
$body_lines[] = "Lead ID:    $lead_id";
$body_lines[] = "Country:    " . ($country ?: '(unknown)') . "   →  Calendar: $calendar_owner";
$body_lines[] = "Page:       " . ($page ?: '(unknown)');
$body_lines[] = "Time (IST): $timestamp_ist";
$body_lines[] = "Time (UTC): $timestamp_utc";
$body_lines[] = "IP:         $ip";
$body_lines[] = "User-Agent: " . substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200);
$body_lines[] = "";
$body_lines[] = "Reply directly to this email to respond to $name.";

$body = implode("\n", $body_lines);

// Subject — try to be specific so multiple leads don't all look alike
$subject_page = $page ?: '/';
$identifier = $name ?: $company ?: 'New';
$subject = "Talhive lead: $identifier  ·  $subject_page";

// ────────────────────────────────────────────────────────────────────
// Build mail headers
// Critical for deliverability:
//   - From: must be on talhive.com domain (else flagged as spoofing)
//   - Reply-To: set to lead's email so reply works directly
//   - MIME-Version: declares plain text
// ────────────────────────────────────────────────────────────────────
$headers = [];
$headers[] = "From: $FROM_NAME <$FROM_ADDRESS>";
$headers[] = "Reply-To: $name <$email>";
$headers[] = "X-Mailer: Talhive-Submit/1.0";
$headers[] = "MIME-Version: 1.0";
$headers[] = "Content-Type: text/plain; charset=UTF-8";
$header_str = implode("\r\n", $headers);

// ────────────────────────────────────────────────────────────────────
// Log first (always works, immune to mail() failure)
// ────────────────────────────────────────────────────────────────────
$log_entry = json_encode([
    'time' => $timestamp_ist,
    'lead_id' => $lead_id,
    'ip' => $ip,
    'name' => $name,
    'email' => $email,
    'company' => $company,
    'phone' => $phone,
    'role' => $role,
    'service' => $service,
    'search_model' => $search_model,
    'lead_intent' => $lead_intent,
    'lead_type' => $lead_type,
    'lead_status' => ($search_model && stripos($search_model, 'No, we are only considering contingent') === 0) ? 'Unqualified but Captured' : 'Qualified',
    'asset' => $asset,
    'message' => $message,
    'page' => $page,
    'country' => $country,
    'lead_tracking_id' => $lead_tracking_id,
    'ft_source' => $ft_source,
    'ft_medium' => $ft_medium,
    'ft_campaign' => $ft_campaign,
    'ft_referrer' => $ft_referrer,
    'ft_landing' => $ft_landing,
    'calendar_owner' => $calendar_owner,
]) . "\n";
@file_put_contents($LOG_FILE, $log_entry, FILE_APPEND | LOCK_EX);

// ────────────────────────────────────────────────────────────────────
// Send email to each recipient
// We send individually (not as CC/BCC) for max deliverability and so each
// recipient sees the email as if sent directly to them.
// ────────────────────────────────────────────────────────────────────
$send_results = [];
foreach ($RECIPIENTS as $to) {
    $sent = @mail($to, $subject, $body, $header_str, "-f$FROM_ADDRESS");
    $send_results[$to] = $sent;
}

// ────────────────────────────────────────────────────────────────────
// Autoresponder to the lead (branded HTML, Gmail/Outlook-safe table layout)
// Booking CTA is country-routed: India -> Pratik (Google), else -> Som (Calendly).
// ────────────────────────────────────────────────────────────────────
$BASE        = 'https://www.talhive.com';
$DECK_URL    = $BASE . '/deck-download?lead_id=' . rawurlencode($lead_id)
             . '&country=' . rawurlencode($country) . '&owner=' . $calendar_owner;
$CASE_URL    = $BASE . '/case-studies';
// Region-based meeting link, included directly in the acknowledgement email.
$CAL_PRATIK  = 'https://calendar.app.google/MDJAVexAawsdPaS96';
$CAL_SOM     = 'https://calendly.com/somnautiyal';
if ($calendar_owner === 'pratik') {
    $book_label  = 'Book a call with Pratik Mokashi';
    $book_url    = $CAL_PRATIK;
    $book_detail = 'India desk &middot; Pratik Mokashi, COO';
} else {
    $book_label  = 'Book a call with Som Nautiyal';
    $book_url    = $CAL_SOM;
    $book_detail = 'Global desk &middot; Som Nautiyal, CEO';
}
$first_name = trim(explode(' ', $name)[0]);
$greeting   = $first_name !== '' ? "Hi {$first_name}," : 'Hi there,';

$navy = '#1C3A5C'; $cream = '#F4F1EA'; $ink = '#171410'; $stone = '#6B6258';

function th_btn($url, $label, $bg, $fg) {
    return '<table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin:0 0 12px 0;">'
         . '<tr><td bgcolor="' . $bg . '" style="border-radius:6px;">'
         . '<a href="' . htmlspecialchars($url) . '" target="_blank" '
         . 'style="display:inline-block;padding:13px 26px;font-family:Arial,Helvetica,sans-serif;'
         . 'font-size:15px;font-weight:bold;color:' . $fg . ';text-decoration:none;border-radius:6px;">'
         . htmlspecialchars($label) . '</a></td></tr></table>';
}

$esc_name = htmlspecialchars($name);

/* ── Segment branch: contingent-only leads get an educational nurture email
   instead of the standard booking autoresponder. submit.php already detects
   this exact qualifier answer for lead_status. ───────────────────────────── */
$is_contingent_only = ($search_model && stripos($search_model, 'No, we are only considering contingent') === 0);

/* Replies to the nurture email fan out via marketing@ (set marketing@ on
   Hostinger to forward to som@, pratik@, shubham@). */
$NURTURE_REPLY_TO = 'marketing@talhive.com';
$BLOG_RVC = $BASE . '/blog/executive-search-vs-contingent-recruitment';

if ($is_contingent_only) {
  /* ---- Educational nurture email (brand voice, no booking CTA) ---- */
  $ar_html = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
    . '<meta name="viewport" content="width=device-width,initial-scale=1"></head>'
    . '<body style="margin:0;padding:0;background:' . $cream . ';">'
    . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="' . $cream . '" style="background:' . $cream . ';padding:24px 0;">'
    . '<tr><td align="center">'
    . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px;background:#ffffff;border-radius:10px;overflow:hidden;">'
    // header
    . '<tr><td bgcolor="' . $navy . '" style="background:' . $navy . ';padding:24px 32px;">'
    . '<span style="font-family:Georgia,\'Times New Roman\',serif;font-size:22px;letter-spacing:3px;color:#ffffff;font-weight:bold;">TALHIVE</span>'
    . '<span style="font-family:Arial,Helvetica,sans-serif;font-size:11px;letter-spacing:2px;color:#9fb3c8;display:block;margin-top:4px;">EXECUTIVE SEARCH</span>'
    . '</td></tr>'
    // headline
    . '<tr><td style="padding:32px 32px 8px 32px;font-family:Georgia,serif;">'
    . '<h1 style="margin:0 0 14px 0;font-size:23px;line-height:1.3;color:' . $navy . ';font-weight:normal;">When executive search is worth it (and when it isn\'t)</h1>'
    . '</td></tr>'
    // body
    . '<tr><td style="padding:4px 32px 8px 32px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.65;color:' . $ink . ';">'
    . '<p style="margin:0 0 14px 0;">' . $greeting . ' thanks for reaching out. You mentioned you are currently considering contingent recruitment, so we want to be straight with you about how we work and let you decide what fits.</p>'
    . '<p style="margin:0 0 14px 0;">Talhive runs executive search. We do not compete with three agencies to fill a role first. We take a small number of mandates and run each as an exclusive, accountable process: a real search thesis, direct outreach to people who are not applying anywhere, motivation tested before the offer, and written intelligence along the way.</p>'
    . '<p style="margin:0 0 14px 0;">That model is not right for every role, and we would rather tell you that than oversell it. Here is the honest line:</p>'
    . '<p style="margin:0 0 14px 0;padding:14px 18px;background:' . $cream . ';border-left:3px solid ' . $navy . ';">Contingent works well when the talent pool is deep, the role is mid-level, and speed and low upfront cost matter most. Executive search earns its fee when the role is senior or scarce, the strongest candidates are off-market, and a wrong hire is expensive to unwind.</p>'
    . '<p style="margin:0 0 14px 0;">For most leadership and specialist hires, the real comparison is not fee percentages. It is the cost of a process built to land the right person versus a lottery ticket on whether an agency happens to surface one.</p>'
    . '<p style="margin:0 0 14px 0;">If your role sits on the contingent side of that line, genuinely, good, you will move faster without us. If it sits on the other side, that is exactly what we do.</p>'
    . '</td></tr>'
    // article CTA
    . '<tr><td style="padding:4px 32px 8px 32px;border-top:1px solid #e8e3d8;">'
    . '<p style="margin:18px 0 6px 0;font-family:Georgia,serif;font-size:18px;color:' . $navy . ';">The full trade-off, with the fee math</p>'
    . '<p style="margin:0 0 14px 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:' . $stone . ';">This is the clearest thing we have written on when each model makes sense, and a simple way to decide.</p>'
    . th_btn($BLOG_RVC, 'Read: Executive Search vs Contingent', $navy, '#ffffff')
    . '</td></tr>'
    // soft close
    . '<tr><td style="padding:8px 32px 28px 32px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.65;color:' . $ink . ';">'
    . '<p style="margin:8px 0 14px 0;">No need to reply unless it is useful. If your thinking shifts, or your current search stalls, just respond to this email and you will reach us directly.</p>'
    . '<p style="margin:0;">Best,<br>The Talhive Team</p>'
    . '</td></tr>'
    // footer
    . '<tr><td bgcolor="' . $navy . '" style="background:' . $navy . ';padding:18px 32px;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.6;color:#9fb3c8;">'
    . 'Talhive &middot; Executive Search &middot; India &amp; Vietnam<br>'
    . '<a href="' . $BASE . '" style="color:#cdd9e5;text-decoration:none;">talhive.com</a> &nbsp;&middot;&nbsp; marketing@talhive.com'
    . '</td></tr>'
    . '</table></td></tr></table></body></html>';

  $ar_subject = 'When executive search is worth it (and when it isn\'t)';
  $ar_reply_to = $NURTURE_REPLY_TO;

} else {
  /* ---- Standard booking autoresponder (unchanged) ---- */
  $ar_subject = 'Thank You for Contacting Talhive';
  $ar_reply_to = $FROM_ADDRESS;
$ar_html = '<!DOCTYPE html><html><head><meta charset="UTF-8">'
  . '<meta name="viewport" content="width=device-width,initial-scale=1"></head>'
  . '<body style="margin:0;padding:0;background:' . $cream . ';">'
  . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="' . $cream . '" style="background:' . $cream . ';padding:24px 0;">'
  . '<tr><td align="center">'
  . '<table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px;background:#ffffff;border-radius:10px;overflow:hidden;">'
  // header
  . '<tr><td bgcolor="' . $navy . '" style="background:' . $navy . ';padding:24px 32px;">'
  . '<span style="font-family:Georgia,\'Times New Roman\',serif;font-size:22px;letter-spacing:3px;color:#ffffff;font-weight:bold;">TALHIVE</span>'
  . '<span style="font-family:Arial,Helvetica,sans-serif;font-size:11px;letter-spacing:2px;color:#9fb3c8;display:block;margin-top:4px;">EXECUTIVE SEARCH</span>'
  . '</td></tr>'
  // section 1
  . '<tr><td style="padding:32px 32px 8px 32px;font-family:Georgia,serif;">'
  . '<h1 style="margin:0 0 14px 0;font-size:24px;line-height:1.25;color:' . $navy . ';font-weight:normal;">Thank you for reaching out to Talhive.</h1>'
  . '<p style="margin:0;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:' . $ink . ';">'
  . $greeting . ' we have received your enquiry and it is now with our team. A Talhive partner will be in touch shortly.</p>'
  . '</td></tr>'
  // section 2
  . '<tr><td style="padding:20px 32px 4px 32px;">'
  . '<p style="margin:0 0 10px 0;font-family:Arial,Helvetica,sans-serif;font-size:12px;letter-spacing:1.5px;color:' . $stone . ';text-transform:uppercase;">What happens next</p>'
  . '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:' . $ink . ';">'
  . '<tr><td style="padding:3px 0;">&bull;&nbsp;&nbsp;We review the hiring requirement.</td></tr>'
  . '<tr><td style="padding:3px 0;">&bull;&nbsp;&nbsp;We evaluate role complexity.</td></tr>'
  . '<tr><td style="padding:3px 0;">&bull;&nbsp;&nbsp;We identify the best search strategy.</td></tr>'
  . '<tr><td style="padding:3px 0;">&bull;&nbsp;&nbsp;We come prepared for the discovery discussion.</td></tr>'
  . '</table></td></tr>'
  // section 3 - deck
  . '<tr><td style="padding:24px 32px 4px 32px;border-top:1px solid #e8e3d8;">'
  . '<p style="margin:18px 0 6px 0;font-family:Georgia,serif;font-size:18px;color:' . $navy . ';">Our company deck</p>'
  . '<p style="margin:0 0 14px 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:' . $stone . ';">A short read on how we run executive search, the proof, and the engagement model.</p>'
  . th_btn($DECK_URL, 'Download Our Company Deck', $navy, '#ffffff')
  . '</td></tr>'
  // section 4 - case studies
  . '<tr><td style="padding:8px 32px 4px 32px;">'
  . '<p style="margin:8px 0 6px 0;font-family:Georgia,serif;font-size:18px;color:' . $navy . ';">Case studies</p>'
  . '<p style="margin:0 0 14px 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:' . $stone . ';">Repeatable senior outcomes across India leadership, GCC and senior technical hiring.</p>'
  . th_btn($CASE_URL, 'View Case Studies', '#ffffff', $navy)
  . '</td></tr>'
  // section 5 - booking
  . '<tr><td style="padding:8px 32px 28px 32px;border-top:1px solid #e8e3d8;">'
  . '<p style="margin:18px 0 6px 0;font-family:Georgia,serif;font-size:18px;color:' . $navy . ';">Start with a 30-minute mandate calibration</p>'
  . '<p style="margin:0 0 14px 0;font-family:Arial,Helvetica,sans-serif;font-size:14px;line-height:1.6;color:' . $stone . ';">You leave with a sharper role, whether or not we work together.</p>'
  . th_btn($book_url, $book_label, '#B91C1C', '#ffffff')
  . '<p style="margin:2px 0 0 0;font-family:Arial,Helvetica,sans-serif;font-size:13px;color:' . $stone . ';">' . $book_detail . '<br>'
  . '<a href="' . htmlspecialchars($book_url) . '" style="color:' . $navy . ';">' . htmlspecialchars($book_url) . '</a></p>'
  . '</td></tr>'
  . '<tr><td bgcolor="' . $navy . '" style="background:' . $navy . ';padding:18px 32px;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.6;color:#9fb3c8;">'
  . 'Talhive &middot; Executive Search &middot; India &amp; Vietnam<br>'
  . '<a href="' . $BASE . '" style="color:#cdd9e5;text-decoration:none;">talhive.com</a> &nbsp;&middot;&nbsp; marketing@talhive.com'
  . '</td></tr>'
  . '</table></td></tr></table></body></html>';
}

$ar_headers = [];
$ar_headers[] = "From: $FROM_NAME <$FROM_ADDRESS>";
$ar_headers[] = "Reply-To: Talhive <$ar_reply_to>";
$ar_headers[] = "X-Mailer: Talhive-Submit/1.0";
$ar_headers[] = "MIME-Version: 1.0";
$ar_headers[] = "Content-Type: text/html; charset=UTF-8";
$ar_header_str = implode("\r\n", $ar_headers);
@mail($email, $ar_subject, $ar_html, $ar_header_str, "-f$FROM_ADDRESS");

// ────────────────────────────────────────────────────────────────────
// Return success (with lead_id so the client can route + attribute)
// (the log file remains the source of truth — grep leads.log)
// ────────────────────────────────────────────────────────────────────
http_response_code(200);
echo json_encode([
    'ok' => true,
    'lead_id' => $lead_id,
    'calendar_owner' => $calendar_owner,
    'country' => $country,
]);
exit;
