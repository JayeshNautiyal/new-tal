<?php
/**
 * Talhive lightweight event logger.
 * Records server-side events (currently: marketing deck downloads) to
 * events.log as one JSON line each. Independent of GA4 — this is the
 * durable, host-side record so attribution survives even if GA4/JS fails.
 *
 * Called by /deck-download (deck-download.html) before it redirects to the PDF.
 * Accepts GET or POST: event, lead_id, country, calendar_owner, page
 */
header('Content-Type: application/json');
header('Cache-Control: no-store');

$LOG = __DIR__ . '/events.log';

function val($k, $max = 120) {
    $v = $_POST[$k] ?? $_GET[$k] ?? '';
    $v = is_string($v) ? trim($v) : '';
    return substr($v, 0, $max);
}

$now    = time();
$entry = [
    'time'           => gmdate('Y-m-d H:i:s', $now + 19800), // IST
    'event'          => val('event') ?: 'unknown',
    'lead_id'        => val('lead_id'),
    'country'        => strtolower(val('country', 8)),
    'calendar_owner' => strtolower(val('calendar_owner', 8)),
    'page'           => val('page', 300),
    'ip'             => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'ua'             => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200),
];
@file_put_contents($LOG, json_encode($entry) . "\n", FILE_APPEND | LOCK_EX);

http_response_code(200);
echo json_encode(['ok' => true]);
