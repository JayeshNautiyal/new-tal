<?php
/**
 * calendly-webhook.php  —  Talhive
 * ---------------------------------------------------------------------------
 * Enforces "company email only" on Calendly bookings (Option B).
 *
 * Calendly calls this endpoint on every `invitee.created` event. If the
 * invitee booked with a personal / free email provider, we:
 *   1. cancel the scheduled event via the Calendly API, and
 *   2. email the invitee asking them to rebook with a company address.
 *
 * This is the only way to *enforce* company-email-only on an embedded
 * Calendly scheduler, because the invitee email field lives inside
 * Calendly's cross-origin iframe and cannot be validated by page JS.
 *
 * -------------------------  ONE-TIME SETUP  --------------------------------
 * 1. Calendly > Account > Integrations > API & webhooks > Personal access
 *    tokens: create a token, paste it into CALENDLY_PAT below (or set the
 *    env var CALENDLY_PAT on the server).
 * 2. Choose any long random string as your signing key and put it in
 *    CALENDLY_SIGNING_KEY below (or env CALENDLY_SIGNING_KEY).
 * 3. Register the webhook (run once from your machine, filling in the token,
 *    the same signing key, and your user/organization URIs from
 *    GET https://api.calendly.com/users/me ):
 *
 *      curl -X POST https://api.calendly.com/webhook_subscriptions \
 *        -H "Authorization: Bearer <CALENDLY_PAT>" \
 *        -H "Content-Type: application/json" \
 *        -d '{
 *              "url": "https://www.talhive.com/calendly-webhook.php",
 *              "events": ["invitee.created"],
 *              "organization": "https://api.calendly.com/organizations/XXXX",
 *              "user": "https://api.calendly.com/users/XXXX",
 *              "scope": "user",
 *              "signing_key": "<CALENDLY_SIGNING_KEY>"
 *            }'
 *
 * 4. Deploy this file to the web root and book a test event with a gmail
 *    address — it should be auto-cancelled within a few seconds.
 * ---------------------------------------------------------------------------
 */

// ----- Config (prefer environment variables; constants are fallbacks) -------
$CALENDLY_PAT         = getenv('CALENDLY_PAT')         ?: 'REPLACE_WITH_CALENDLY_PERSONAL_ACCESS_TOKEN';
$CALENDLY_SIGNING_KEY = getenv('CALENDLY_SIGNING_KEY') ?: 'REPLACE_WITH_YOUR_WEBHOOK_SIGNING_KEY';

$LOG_FILE   = __DIR__ . '/calendly-webhook.log';
$NOTIFY     = ['som@talhive.com', 'pratik@talhive.com']; // internal heads-up on a cancel
$FROM       = 'search@talhive.com';                       // must be a real mailbox on talhive.com
$BOOK_URL   = 'https://www.talhive.com/contact';          // where to send them to rebook

// Same free-provider list used by the contact form (submit.php).
$PERSONAL_DOMAINS = [
    'gmail.com', 'googlemail.com',
    'yahoo.com', 'yahoo.co.in', 'yahoo.co.uk', 'ymail.com', 'rocketmail.com',
    'hotmail.com', 'outlook.com', 'live.com', 'msn.com',
    'aol.com', 'icloud.com', 'me.com', 'mac.com',
    'protonmail.com', 'proton.me',
    'gmx.com', 'mail.com',
];

// ---------------------------------------------------------------------------
function wlog($msg) {
    global $LOG_FILE;
    @file_put_contents($LOG_FILE, '[' . date('c') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
}
function respond($code, $msg) { http_response_code($code); echo $msg; exit; }

// Only accept POST.
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') respond(405, 'Method Not Allowed');

$raw = file_get_contents('php://input');
if ($raw === '' || $raw === false) respond(400, 'Empty body');

// ----- Verify Calendly signature (t=timestamp,v1=hmac) ----------------------
// Header format: "Calendly-Webhook-Signature: t=1699999999,v1=abcdef..."
$sigHeader = $_SERVER['HTTP_CALENDLY_WEBHOOK_SIGNATURE'] ?? '';
if ($CALENDLY_SIGNING_KEY && strpos($CALENDLY_SIGNING_KEY, 'REPLACE_WITH') === false) {
    $t = ''; $v1 = '';
    foreach (explode(',', $sigHeader) as $part) {
        $kv = explode('=', trim($part), 2);
        if (count($kv) === 2) {
            if ($kv[0] === 't')  $t  = $kv[1];
            if ($kv[0] === 'v1') $v1 = $kv[1];
        }
    }
    if ($t === '' || $v1 === '') { wlog('REJECT missing signature header'); respond(403, 'No signature'); }
    $expected = hash_hmac('sha256', $t . '.' . $raw, $CALENDLY_SIGNING_KEY);
    if (!hash_equals($expected, $v1)) { wlog('REJECT bad signature'); respond(403, 'Bad signature'); }
    // Optional replay guard: reject signatures older than 10 minutes.
    if (abs(time() - (int)$t) > 600) { wlog('REJECT stale signature t=' . $t); respond(403, 'Stale'); }
} else {
    wlog('WARN signing key not configured — skipping signature verification');
}

// ----- Parse payload --------------------------------------------------------
$data = json_decode($raw, true);
if (!is_array($data)) respond(400, 'Bad JSON');

$event = $data['event'] ?? '';
if ($event !== 'invitee.created') respond(200, 'Ignored'); // ack other events

$p        = $data['payload'] ?? [];
$email    = strtolower(trim($p['email'] ?? ''));
$name     = trim($p['name'] ?? '');
$evUri    = $p['scheduled_event']['uri'] ?? ($p['event'] ?? '');
$domain   = ($email && strpos($email, '@') !== false) ? substr(strrchr($email, '@'), 1) : '';

if ($email === '' || $domain === '') { wlog('No email in payload'); respond(200, 'No email'); }

// Company email -> allow the booking to stand.
if (!in_array($domain, $PERSONAL_DOMAINS, true)) {
    wlog("ALLOW $email");
    respond(200, 'OK (company email)');
}

// ----- Personal email -> cancel the scheduled event -------------------------
wlog("PERSONAL EMAIL $email — cancelling $evUri");

if (!$evUri || !$CALENDLY_PAT || strpos($CALENDLY_PAT, 'REPLACE_WITH') !== false) {
    wlog('ERROR cannot cancel — missing event URI or PAT');
    respond(200, 'Cannot cancel (config)');
}

$cancelUrl = rtrim($evUri, '/') . '/cancellation';
$body = json_encode([
    'reason' => 'This booking used a personal email address. Talhive works with companies, '
              . 'so please rebook using your official company email at ' . $BOOK_URL . '.'
]);

$ch = curl_init($cancelUrl);
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $body,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 15,
    CURLOPT_HTTPHEADER     => [
        'Authorization: Bearer ' . $CALENDLY_PAT,
        'Content-Type: application/json',
    ],
]);
$resp = curl_exec($ch);
$http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$cerr = curl_error($ch);
curl_close($ch);

if ($http >= 200 && $http < 300) {
    wlog("CANCELLED $email ($http)");
} else {
    wlog("CANCEL FAILED $email http=$http err=$cerr resp=" . substr((string)$resp, 0, 300));
}

// ----- Notify the invitee (Calendly also emails its own cancellation) -------
if ($email) {
    $subject = 'Please rebook with your company email — Talhive';
    $msg = "Hi " . ($name ?: 'there') . ",\n\n"
         . "Thanks for booking time with Talhive. We work exclusively with companies, "
         . "so we can only hold meetings booked with an official company email address.\n\n"
         . "Your session was cancelled because it used a personal email ($email). "
         . "Please rebook using your company email here:\n$BOOK_URL\n\n"
         . "Apologies for the extra step, and we look forward to speaking.\n\n"
         . "— Talhive";
    $headers = "From: Talhive <$FROM>\r\nReply-To: $FROM\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    @mail($email, $subject, $msg, $headers);
}

// Internal heads-up.
if (!empty($NOTIFY)) {
    @mail(implode(',', $NOTIFY), 'Calendly booking auto-cancelled (personal email)',
          "Auto-cancelled a Calendly booking.\n\nName: $name\nEmail: $email\nEvent: $evUri\n",
          "From: Talhive <$FROM>\r\n");
}

respond(200, 'Cancelled (personal email)');
